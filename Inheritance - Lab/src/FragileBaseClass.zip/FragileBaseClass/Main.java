package FragileBaseClass;

public class Main {
}
