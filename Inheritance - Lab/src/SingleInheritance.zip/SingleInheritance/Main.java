package SingleInheritance;

public class Main {
    public static void main(String[] args) {
       Cat cat = new Cat();
       Dog dog = new Dog();

       dog.eat();
       cat.eat();

       dog.bark();
       cat.meow();
    }
}
