import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.sql.SQLOutput;
import java.util.*;

public class Main {
        public static void main(String[] args) throws Exception {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            int num = Integer.parseInt(reader.readLine());
            List<Employee> listOfEmpl = new ArrayList<>();

            for (int i = 0; i < num; i++) {

                String[] tokens = reader.readLine().split(" ");
                String name = tokens[0];
                double salary = Double.parseDouble(tokens[1]);
                String position = tokens[2];
                String department = tokens[3];
                String mail = "";
                int age = 0;
                Employee employee = new Employee(name,salary,position,department);

                if (tokens.length == 5){
                    if (Character.isLetter(tokens[4].charAt(0))){
                        mail = tokens[4];
                        employee.setAge(-1);
                        employee.setEmail(mail);
                    }else{
                        age = Integer.parseInt(tokens[4]);
                        employee.setEmail("n/a");
                        employee.setAge(age);
                    }
                }else if (tokens.length == 6){
                    if (Character.isLetter(tokens[4].charAt(0))){
                        mail = tokens[4];
                        employee.setEmail(mail);
                    }else{
                        age = Integer.parseInt(tokens[4]);
                        employee.setAge(age);
                    }
                    if (Character.isLetter(tokens[5].charAt(0))){
                        mail = tokens[5];
                        employee.setEmail(mail);
                    }else{
                        age = Integer.parseInt(tokens[5]);
                        employee.setAge(age);
                    }
                }
                listOfEmpl.add(employee);
            }

            Map<String, ArrayList<Double>> departSalary = new HashMap<>();

            for (Employee employee : listOfEmpl) {
                if (!departSalary.containsKey(employee.getDepartment())){
                    departSalary.put(employee.getDepartment(), new ArrayList<>());
                    departSalary.get(employee.getDepartment()).add(employee.getSalary());
                }else{
                    departSalary.get(employee.getDepartment()).add(employee.getSalary());
                }
            }

            departSalary.entrySet().stream().sorted((dep1,dep2)->{

                 final double[]  av1 = {0.0};
                final double[]  av2 = {0.0};
                dep1.getValue().forEach(s -> av1[0] += s);
                dep2.getValue().forEach(s -> av2[0] += s);

                return Double.compare((av2[0] / dep2.getValue().size()),(av1[0] / dep1.getValue().size()));
            }).limit(1).forEach(dep-> {
                System.out.printf("Highest Average Salary: %s%n", dep.getKey());
                List<Employee> finalList = new ArrayList<>();
                for (Employee employee : listOfEmpl) {
                    if (employee.getDepartment().equals(dep.getKey())){
                        finalList.add(employee);
                    }
                }
                finalList.stream().sorted((x,y)-> Double.compare(y.getSalary(),x.getSalary())).forEach(x-> System.out.println(x.toString()));
            } );
        }
}
