package BookShop;

public class GoldenEditionBook extends Book {

    public GoldenEditionBook(String author,String title, double price){
        super(title, author, price);
    }
    @Override
    public void setPrice(double price){
         super.setPrice(price + price * 0.3);
    }
}
