package BookShop;

public class Book {
    private String title;
    private String author;
    private double price;

    public Book(String author, String title, double price) {
        this.setTitle(title);
        this.setAuthor(author);
        this.setPrice(price);
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {

        this.title = title;
    }

    public String getAuthor() {
        return this.author;
    }

    public void setAuthor(String author) {
        if (author.length() < 3){
            throw new IllegalArgumentException("Title not valid!");
        }
        String[] firstSecondName = author.split(" ");
        if (firstSecondName.length > 1 ){
            char[] secondName = firstSecondName[1].toCharArray();
                if (Character.isDigit(secondName[0])){
                    throw new IllegalArgumentException("Author not valid!");
                }
        }

        this.author = author;
    }

    public double getPrice() {
        return this.price;
    }

    public void setPrice(double price) {
        if (price <= 0){
            throw new IllegalArgumentException("Price not valid!");
        }
        this.price = price;
    }

    @Override
    public String toString(){

        return "Type: " + this.getClass().getSimpleName() + "\n" + "Title: "
                + this.getTitle() + "\n" + "Author: " + this.getAuthor() + "\n"
        + "Price: " + this.getPrice() + "\n";
    }
}
