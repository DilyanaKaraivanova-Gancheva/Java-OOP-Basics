package Wildfarm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String input = reader.readLine();

            while (!("End".equals(input))) {
                String inputFood = reader.readLine();

                String[] tokensFood = inputFood.split(" ");
                String[] tokensAnimal = input.split(" ");
                Food food = null;
                switch (tokensFood[0]) {
                    case "Vegetable":
                        food = new Vegetable(Integer.parseInt(tokensFood[1]));
                        break;
                    case "Meat":
                       food = new Meat(Integer.parseInt(tokensFood[1]));
                        break;
                }

                    switch (tokensAnimal[0]) {
                        case "Cat":
                            Animal cat = new Cat(tokensAnimal[1], Double.parseDouble(tokensAnimal[2]), tokensAnimal[3], tokensAnimal[4]);
                            cat.makeSound();
                            cat.eat(food);
                            System.out.println(cat);
                            break;
                        case "Tiger":
                            Animal tiger = new Tiger(tokensAnimal[1], Double.parseDouble(tokensAnimal[2]), tokensAnimal[3]);
                            tiger.makeSound();
                            tiger.eat(food);
                            System.out.println(tiger);
                            break;
                        case "Mouse":
                            Animal mouse = new Mouse(tokensAnimal[1], Double.parseDouble(tokensAnimal[2]), tokensAnimal[3]);
                            mouse.makeSound();
                            mouse.eat(food);
                            System.out.println(mouse);
                            break;
                        case "Zebra":
                            Animal zebra = new Zebra(tokensAnimal[1], Double.parseDouble(tokensAnimal[2]), tokensAnimal[3]);
                            zebra.makeSound();
                            zebra.eat(food);
                            System.out.println(zebra);
                            break;
                    }
                input = reader.readLine();
            }
    }
}
