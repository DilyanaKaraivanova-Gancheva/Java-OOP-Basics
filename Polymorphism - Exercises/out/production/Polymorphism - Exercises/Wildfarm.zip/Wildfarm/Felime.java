package Wildfarm;

public abstract class Felime extends Mammal{

    public Felime( String animalName, Double animalWeight, String livingRegion) {
        super(animalName, animalWeight, livingRegion);
    }
}
