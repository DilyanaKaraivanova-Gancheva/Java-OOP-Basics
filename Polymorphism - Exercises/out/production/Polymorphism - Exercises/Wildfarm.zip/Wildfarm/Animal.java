package Wildfarm;

public abstract class Animal {
    private String animalName;
    private Double animalWeight;
    private int foodEaten;

    public Animal( String animalName, Double animalWeight) {
        this.setAnimalName(animalName);
        this.setAnimalWeight(animalWeight);
        this.setFoodEaten(foodEaten);
    }

    public String getAnimalName() {
        return animalName;
    }

    private void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

    public Double getAnimalWeight() {
        return animalWeight;
    }

    private void setAnimalWeight(Double animalWeight) {
        this.animalWeight = animalWeight;
    }

    public Integer getFoodEaten() {
        return foodEaten;
    }

     void setFoodEaten(Integer foodEaten) {
        this.foodEaten = foodEaten;
    }

    public abstract void makeSound();
    public abstract void eat(Food food);
}
