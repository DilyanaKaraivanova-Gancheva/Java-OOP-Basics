import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Map<Integer, BankAccount> acccounts = new HashMap<>();
        String input = reader.readLine();

        while (!"End".equals(input)) {
            String[] tokens = input.split(" ");
            String command = tokens[0];
            int id = Integer.parseInt(tokens[1]);
            double amount = 0;

            if (tokens.length > 2) {
                amount = Double.parseDouble(tokens[2]);
            }
            switch (command) {
                case "Create":
                    if (!acccounts.containsKey(id)) {
                        BankAccount  account = new BankAccount();
                        account.setId(id);
                        acccounts.put(id, account);
                    } else {
                        System.out.printf("Account already exists%n");
                    }
                    break;
                case "Deposit":
                    if (!acccounts.containsKey(id)) {
                        System.out.printf("Account does not exist%n");
                    } else {
                        acccounts.get(id).deposit(amount);
                    }
                    break;
                case "Withdraw":
                    if (!acccounts.containsKey(id)) {
                        System.out.printf("Account does not exist%n");
                    }else {
                        if (acccounts.get(id).getBalance() < amount) {
                            System.out.printf("Insufficient balance%n");
                        } else {
                            acccounts.get(id).withdraw(amount);
                        }
                    }
                    break;
                case "Print":
                    if (!acccounts.containsKey(id)) {
                        System.out.printf("Account does not exist%n");
                    }else {
                        System.out.printf("Account ID%d, balance %.2f%n", id, acccounts.get(id).getBalance());
                    }
                    break;
            }
            input = reader.readLine();
        }
    }
}